#ifndef MENSAJES_H
#define MENSAJES_H

enum saludo {HOLA, CHAU, QUE_TAL, ECHAR};
extern const char *mensajes[];

#endif
