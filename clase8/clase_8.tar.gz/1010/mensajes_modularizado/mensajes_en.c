#include "mensajes.h"

const char *mensajes[] = {
    [HOLA] = "Hello",
    [CHAU] = "Goodbye",
    [QUE_TAL] = "Jaguar iu",
    [ECHAR] = "Get out!",
};

