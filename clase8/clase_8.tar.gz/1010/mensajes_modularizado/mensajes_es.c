#include "mensajes.h"

const char *mensajes[] = {
    [HOLA] = "Hola",
    [CHAU] = "Chau",
    [QUE_TAL] = "Que tal",
    [ECHAR] = "Andate!",
};

