#ifndef COMMON_H
#define COMMON_H

typedef enum { FALSE, TRUE } tbool;

typedef unsigned char uchar;

#endif /* COMMON_H */
