#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <assert.h>

#include "tda.h"
#include "status.h"
#include "operaciones.h"
#include "direccionamiento.h"
#include "diccionario.h"

int main(int argc, char * argv[]) {

	long ciclos = 0;
    mos6502_t * micro = mos_crear();

  //  if(argc < 2 || argc > 6){
	//	fprintf(stderr,"Ingrese la cantidad exacta de argumentos\n");
       // return -1;
   // }

	mos_cargar_rom(micro,argv[1]);

//printf("0x%04x\n",micro->pc);
	//micro->sp = 0xff;
/*
    if(!strcmp(argv[2],"-ciclos")){
		ciclos = atol(argv[3]);
		micro -> ciclos = ciclos;
		for(size_t i=0; i< micro -> ciclos;i++){
			mos_ejecutar_instruccion(micro);
			mos_setear_log(micro,"archivo-log.txt");
		}
	}
    if(!strcmp(argv[2],"-log")){
		for(size_t i=0; i< micro -> ciclos;i++){
			mos_ejecutar_instruccion(micro);
			mos_setear_log(micro,argv[3]);
		}
    }

    if(!strcmp(argv[2],"-ciclos") && !strcmp(argv[4],"-log")){
		ciclos = atol(argv[3]);
		micro -> ciclos = ciclos;
		for(size_t i=0; i< micro -> ciclos;i++){
			mos_ejecutar_instruccion(micro);
			mos_setear_log(micro,argv[5]);
		}
	}*/
	mos_setear_log(micro, argv[2]);
	//mos_ejecutar_instruccion(micro);

	while(micro->ciclos < 10000){
	mos_ejecutar_instruccion(micro);
	mos_setear_log(micro, argv[2]);
   }	/*for(size_t i=0; argv[i] != NULL; i++){
		if(!strcmp(argv[i],"-ciclos")){
			ciclos = atol(argv[i+1]);	
			micro -> ciclos = ciclos;
			for(size_t i=0; i < micro -> ciclos;i++){
				mos_ejecutar_instruccion(micro);
				mos_setear_log(micro,"archivo-log.txt");
			}
		}else if(!strcmp(argv[i],"-log")){
			for(size_t i=0; i < micro -> ciclos;i++){
				mos_ejecutar_instruccion(micro);
				mos_setear_log(micro,argv[i+1]);
			}
    	}
	}
*/

	mos_destruir(micro);

    return 0;
}
